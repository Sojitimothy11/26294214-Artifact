"""
divergence.py
--------------
Stage 4: Price Growth Index, Earnings Growth Index (both rebased to
2005 = 100), and the Divergence Index (their difference).

The Divergence Index is the measure that Dissertation Table 7 currently
claims exists but does not (see prior model audit). It's a genuinely
useful, genuinely simple addition: a single number per year that
quantifies how far price growth has outpaced earnings growth, which is
exactly the story Page 2 of the dashboard currently tells only visually
via a dual-line chart.
"""
import pandas as pd
from aggregate import build_national_summary

BASE_YEAR = 2005


def build_divergence_index(national: pd.DataFrame) -> pd.DataFrame:
    df = national.sort_values("Year").copy()
    base = df.loc[df["Year"] == BASE_YEAR]
    if base.empty:
        raise ValueError(f"base year {BASE_YEAR} not present in national summary")
    base_price = base["avg_house_price"].iloc[0]
    base_earnings = base["avg_implied_lq_earnings"].iloc[0]

    df["price_growth_index"] = df["avg_house_price"] / base_price * 100
    df["earnings_growth_index"] = df["avg_implied_lq_earnings"] / base_earnings * 100
    df["divergence_index"] = df["price_growth_index"] - df["earnings_growth_index"]

    return df[["Year", "price_growth_index", "earnings_growth_index", "divergence_index"]]


if __name__ == "__main__":
    from ingest import load_fact_table
    fact = load_fact_table()
    national = build_national_summary(fact)
    div = build_divergence_index(national)
    print(div.to_string(index=False))
    peak = div.loc[div["divergence_index"].idxmax()]
    print(f"\nPeak divergence: {peak['divergence_index']:.2f} index points in {int(peak['Year'])}")
