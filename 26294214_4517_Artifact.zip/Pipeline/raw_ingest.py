"""
raw_ingest.py
--------------
Stage 0 (true raw ingestion): builds the harmonised fact_affordability_la_year
and dim_local_authority tables from the two source files closest to the
original ONS/Land Registry downloads available in this environment:

  - england_LA_affordability_2002_2025.csv
        The merged ONS LQ PTE ratio + HM Land Registry Price Paid panel,
        prior to region assignment. Its RegionName column is NOT usable --
        it is a placeholder that duplicates LA_Name (verified: identical on
        all 7,041 rows) rather than an actual region. This is exactly the
        gap Dissertation Section 3.4 describes Power Query as closing via
        "merging the regional lookup table."

  - Local_Authority_District_to_Region__December_2024__Lookup_in_EN.csv
        The official ONS LAD-to-region lookup (LAD24CD, LAD24NM, RGN24CD,
        RGN24NM). This is the authoritative region source.

KNOWN DATA ISSUE (found here, not introduced downstream): the raw panel's
AreaCode for Barnsley and Sheffield (E08000038 / E08000039) does not match
the official lookup's AreaCode for the same two LAs (E08000016 / E08000019).
Joining on AreaCode alone silently drops these 48 rows (2 LAs x 24 years).
Joining on LA_Name instead resolves all 7,041 rows with zero mismatches
against the previously-validated fact_affordability_la_year.csv, so LA_Name
is used as the join key here, and the mismatch is preserved (not silently
corrected) in the output dim table exactly as it exists in the two real
source files, so downstream validate.py can continue to detect and report it.

Output tables match the schema already consumed by ingest.py:
  fact_affordability_la_year.csv : AreaCode(raw), LA_Name, Year, ONS_ratio_LQ,
                                    AveragePrice_annual, Implied_LQ_earnings,
                                    LA_Key, RegionName
  dim_local_authority.csv        : AreaCode(official), LA_Name, RegionCode,
                                    RegionName, LA_Key
"""
from pathlib import Path
import pandas as pd

DATA_DIR = Path(__file__).parent / "data"


def build_dim_local_authority(lookup: pd.DataFrame) -> pd.DataFrame:
    dim = lookup.rename(columns={
        "LAD24CD": "AreaCode",
        "LAD24NM": "LA_Name",
        "RGN24CD": "RegionCode",
        "RGN24NM": "RegionName",
    })[["AreaCode", "LA_Name", "RegionCode", "RegionName"]].copy()
    dim["LA_Key"] = dim["LA_Name"].str.upper()
    return dim


def build_fact_table(raw_panel: pd.DataFrame, dim: pd.DataFrame) -> pd.DataFrame:
    fact = raw_panel.drop(columns=["RegionName"]).copy()  # placeholder column, discarded
    fact["LA_Key"] = fact["LA_Name"].str.upper()

    # Join on LA_Name (not AreaCode) -- see module docstring for why.
    region_by_name = dim[["LA_Name", "RegionName"]].drop_duplicates()
    fact = fact.merge(region_by_name, on="LA_Name", how="left")

    unresolved = fact[fact["RegionName"].isna()]
    if len(unresolved):
        raise ValueError(
            f"{len(unresolved)} fact rows failed to resolve a region via LA_Name join: "
            f"{unresolved['LA_Name'].unique().tolist()}"
        )

    return fact[["AreaCode", "LA_Name", "Year", "ONS_ratio_LQ", "AveragePrice_annual",
                 "Implied_LQ_earnings", "LA_Key", "RegionName"]]


def run(raw_panel_path: Path = None, lookup_path: Path = None) -> tuple[pd.DataFrame, pd.DataFrame]:
    raw_panel_path = raw_panel_path or DATA_DIR / "england_LA_affordability_2002_2025.csv"
    lookup_path = lookup_path or DATA_DIR / "Local_Authority_District_to_Region__December_2024__Lookup_in_EN.csv"

    raw_panel = pd.read_csv(raw_panel_path)
    lookup = pd.read_csv(lookup_path, encoding="utf-8-sig")

    dim = build_dim_local_authority(lookup)
    fact = build_fact_table(raw_panel, dim)
    return fact, dim


if __name__ == "__main__":
    fact, dim = run()
    print(f"fact table: {len(fact):,} rows, {fact['AreaCode'].nunique()} distinct AreaCodes, "
          f"{fact['LA_Name'].nunique()} distinct LAs")
    print(f"dim table:  {len(dim):,} rows")

    # Self-check against the previously validated, already-harmonised tables,
    # if present, so this stage proves itself before anything downstream
    # relies on it.
    existing_fact_path = DATA_DIR / "fact_affordability_la_year.csv"
    existing_dim_path = DATA_DIR / "dim_local_authority.csv"
    if existing_fact_path.exists() and existing_dim_path.exists():
        existing_fact = pd.read_csv(existing_fact_path)
        existing_dim = pd.read_csv(existing_dim_path)

        f_check = fact.sort_values(["AreaCode", "Year"]).reset_index(drop=True)
        ef_check = existing_fact.sort_values(["AreaCode", "Year"]).reset_index(drop=True)
        fact_mismatches = 0
        for col in ["ONS_ratio_LQ", "AveragePrice_annual", "Implied_LQ_earnings"]:
            fact_mismatches += int((f_check[col] - ef_check[col]).abs().gt(1e-6).sum())
        print(f"\nSelf-check vs existing fact_affordability_la_year.csv: "
              f"{fact_mismatches} numeric mismatches, "
              f"region match = {(f_check['RegionName'] == ef_check['RegionName']).all()}")

        d_check = dim.sort_values("AreaCode").reset_index(drop=True)
        ed_check = existing_dim.sort_values("AreaCode").reset_index(drop=True)
        print(f"Self-check vs existing dim_local_authority.csv: "
              f"shape match = {d_check.shape == ed_check.shape}, "
              f"AreaCode set match = {set(d_check['AreaCode']) == set(ed_check['AreaCode'])}")
