"""
inferential.py
---------------
Stage 5: inferential statistics that a DAX/Power BI layer cannot
reasonably provide. This directly addresses Dissertation Section 3.10's
own stated limitation ("the Power BI dashboard... does not incorporate
inferential statistical testing") and gives empirical teeth to the
Chapter 2 citations of spatial econometrics (Anselin, 1988) that are
currently not matched by any actual spatial statistic in Chapter 4.

Three tests:
  1. Mann-Kendall trend test  -- is the national median ratio trend
     statistically significant, not just visually apparent?
  2. Kruskal-Wallis H test    -- do LA-level ratios differ significantly
     across regions in a given year (non-parametric ANOVA analogue,
     appropriate given the ratio distribution is right-skewed)?
  3. Moran's I                -- is there significant positive spatial
     autocorrelation in regional mean ratios (i.e. do neighbouring
     regions have more similar affordability than chance would predict)?

CAVEAT on Moran's I: this environment has no network access to download
authoritative LA/region boundary files, so spatial weights are built from
a manually-specified contiguity matrix of England's 9 NUTS1-equivalent
regions based on standard administrative geography (see REGION_ADJACENCY
below). This is defensible for a regional-level demonstration but is a
simplification -- n=9 regions gives limited statistical power, and a
production-grade version should replace this with a real queen-contiguity
or k-nearest-neighbour weights matrix built from ONS boundary files
(e.g. via geopandas + libpysal), ideally at LA level (n=294) rather than
regional level (n=9). This is flagged explicitly as a limitation, not
hidden.
"""
from itertools import combinations
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats

from ingest import load_fact_table
from aggregate import build_national_summary

# --- 1. Mann-Kendall trend test -------------------------------------------

def mann_kendall(series: pd.Series) -> dict:
    """
    Non-parametric test for a monotonic trend. Returns S statistic,
    Kendall's tau, z-score, and a two-sided p-value. Uses the standard
    variance formula without tie correction (no tied values expected in
    a continuous ratio series over distinct years).
    """
    x = series.dropna().to_numpy()
    n = len(x)
    s = sum(np.sign(x[j] - x[i]) for i, j in combinations(range(n), 2))
    var_s = n * (n - 1) * (2 * n + 5) / 18
    if s > 0:
        z = (s - 1) / np.sqrt(var_s)
    elif s < 0:
        z = (s + 1) / np.sqrt(var_s)
    else:
        z = 0.0
    p_value = 2 * (1 - stats.norm.cdf(abs(z)))
    tau = s / (0.5 * n * (n - 1))
    return {"n": n, "S": s, "kendall_tau": tau, "z": z, "p_value": p_value,
            "significant_at_0.05": bool(p_value < 0.05)}


# --- 2. Kruskal-Wallis test across regions ---------------------------------

def kruskal_wallis_by_region(fact: pd.DataFrame, year: int) -> dict:
    """
    Tests whether the distribution of LA-level ratios differs significantly
    across regions in a given year. Non-parametric analogue of one-way
    ANOVA -- appropriate here because LA-level ratios are right-skewed
    (a handful of very high-ratio London boroughs), violating the normality
    assumption ANOVA requires.
    """
    scoped = fact[fact["Year"] == year]
    groups = [g["ONS_ratio_LQ"].to_numpy() for _, g in scoped.groupby("RegionName")]
    region_names = list(scoped.groupby("RegionName").groups.keys())
    h_stat, p_value = stats.kruskal(*groups)
    return {
        "year": year,
        "n_regions": len(groups),
        "n_observations": sum(len(g) for g in groups),
        "H_statistic": h_stat,
        "p_value": p_value,
        "significant_at_0.05": bool(p_value < 0.05),
        "region_medians": {name: float(np.median(g)) for name, g in zip(region_names, groups)},
    }


# --- 3. Moran's I on regional means -----------------------------------------

# Approximate contiguity (shared-border) matrix for England's 9 regions.
# See module docstring caveat above.
REGION_ADJACENCY = {
    "North East": ["North West", "Yorkshire and The Humber"],
    "North West": ["North East", "Yorkshire and The Humber", "West Midlands", "East Midlands"],
    "Yorkshire and The Humber": ["North East", "North West", "East Midlands"],
    "East Midlands": ["Yorkshire and The Humber", "North West", "West Midlands", "East of England", "South East"],
    "West Midlands": ["North West", "East Midlands", "South West", "South East"],
    "East of England": ["East Midlands", "London", "South East"],
    "London": ["East of England", "South East"],
    "South East": ["East Midlands", "West Midlands", "East of England", "London", "South West"],
    "South West": ["West Midlands", "South East"],
}


def build_weights_matrix(regions: list[str]) -> np.ndarray:
    """Row-standardised binary contiguity weights matrix, ordered by `regions`."""
    n = len(regions)
    w = np.zeros((n, n))
    idx = {r: i for i, r in enumerate(regions)}
    for r, neighbours in REGION_ADJACENCY.items():
        if r not in idx:
            continue
        for nb in neighbours:
            if nb in idx:
                w[idx[r], idx[nb]] = 1.0
    row_sums = w.sum(axis=1, keepdims=True)
    row_sums[row_sums == 0] = 1  # avoid div-by-zero for isolated units (none expected here)
    return w / row_sums


def morans_i(values: pd.Series, units: list[str], weights: np.ndarray | None = None) -> dict:
    """
    Global Moran's I for spatial autocorrelation, with the analytical
    (randomisation-assumption) expectation, variance, and z-score --
    no simulation needed.

    If `weights` is None, falls back to the approximate 9-region
    contiguity matrix built from `units` via REGION_ADJACENCY (see
    module docstring caveat). If `weights` is supplied (a real,
    row-standardised n x n matrix, e.g. produced by
    build_spatial_weights.py at LA level), that is used instead --
    this is the authoritative path.
    """
    x = values.to_numpy(dtype=float)
    n = len(x)
    w = weights if weights is not None else build_weights_matrix(units)
    x_bar = x.mean()
    dev = x - x_bar
    num = 0.0
    for i in range(n):
        for j in range(n):
            num += w[i, j] * dev[i] * dev[j]
    denom = np.sum(dev ** 2)
    s0 = w.sum()
    i_stat = (n / s0) * (num / denom) if denom != 0 else np.nan

    e_i = -1.0 / (n - 1)
    s1 = 0.5 * np.sum((w + w.T) ** 2)
    s2 = np.sum((w.sum(axis=1) + w.sum(axis=0)) ** 2)
    b2 = (np.sum(dev ** 4) / n) / (denom / n) ** 2
    var_i = (
        (n * ((n ** 2 - 3 * n + 3) * s1 - n * s2 + 3 * s0 ** 2)
         - b2 * ((n ** 2 - n) * s1 - 2 * n * s2 + 6 * s0 ** 2))
        / ((n - 1) * (n - 2) * (n - 3) * s0 ** 2)
    )
    z = (i_stat - e_i) / np.sqrt(var_i) if var_i > 0 else np.nan
    p_value = 2 * (1 - stats.norm.cdf(abs(z))) if not np.isnan(z) else np.nan

    return {"n_units": n, "morans_I": i_stat, "expected_I": e_i, "z": z,
            "p_value": p_value, "significant_at_0.05": bool(p_value < 0.05) if not np.isnan(p_value) else None,
            "weights_source": "real (LA-level, supplied)" if weights is not None else "approximate (9-region contiguity)"}


def local_morans_i(values: pd.Series, units: list[str], weights: np.ndarray) -> pd.DataFrame:
    """
    Local Indicators of Spatial Association (LISA / local Moran's I) --
    one statistic per unit, identifying specific hot-spot / cold-spot
    clusters rather than a single global summary. Requires real weights
    (this is not run against the approximate regional matrix, which is
    too coarse at n=9 for a meaningful local decomposition).

    Classifies each unit into a quadrant:
      HH (High-High) -- a high-ratio LA surrounded by high-ratio neighbours
      LL (Low-Low)   -- a low-ratio LA surrounded by low-ratio neighbours
      HL (High-Low)  -- a high-ratio LA surrounded by low-ratio neighbours (spatial outlier)
      LH (Low-High)  -- a low-ratio LA surrounded by high-ratio neighbours (spatial outlier)

    Significance is assessed via a conditional permutation test (999
    permutations), the standard approach when an analytical local
    variance formula is not used.
    """
    rng = np.random.default_rng(seed=42)
    x = values.to_numpy(dtype=float)
    n = len(x)
    z = x - x.mean()
    m2 = np.sum(z ** 2) / n

    local_i = np.array([
        (z[i] / m2) * np.sum(weights[i, :] * z) for i in range(n)
    ])

    n_perm = 999
    p_values = np.ones(n)
    for i in range(n):
        neighbours_w = weights[i, :]
        others = np.delete(np.arange(n), i)
        sim_stats = np.empty(n_perm)
        for p in range(n_perm):
            permuted = rng.permutation(z[others])
            sim_stats[p] = (z[i] / m2) * np.sum(neighbours_w[others] * permuted)
        p_values[i] = (np.sum(np.abs(sim_stats) >= abs(local_i[i])) + 1) / (n_perm + 1)

    lag = weights @ z
    quadrant = []
    for zi, lagi in zip(z, lag):
        if zi >= 0 and lagi >= 0:
            quadrant.append("HH")
        elif zi < 0 and lagi < 0:
            quadrant.append("LL")
        elif zi >= 0 and lagi < 0:
            quadrant.append("HL")
        else:
            quadrant.append("LH")

    return pd.DataFrame({
        "unit": units,
        "local_I": local_i,
        "p_value": p_values,
        "significant_at_0.05": p_values < 0.05,
        "quadrant": quadrant,
    }).sort_values("p_value")


def load_real_weights(weights_path: Path) -> tuple[np.ndarray, list[str]]:
    """
    Load a real, precomputed spatial weights matrix produced by
    build_spatial_weights.py (run locally with geopandas + libpysal
    against authoritative ONS boundary data). Expected format: a CSV
    with an 'AreaCode' index column and one column per neighbour
    AreaCode, row-standardised.
    """
    df = pd.read_csv(weights_path, index_col=0)
    return df.to_numpy(dtype=float), list(df.index)


def _la_values_for_year(fact: pd.DataFrame, dim: pd.DataFrame, year: int,
                          area_codes: list[str], weights: np.ndarray) -> tuple[pd.Series, np.ndarray, list[str]]:
    """
    Build a Series of ONS_ratio_LQ values for `year`, aligned to `area_codes`
    (the weights matrix's official-AreaCode ordering), joined via LA_Key to
    avoid the Barnsley/Sheffield AreaCode inconsistency (see raw_ingest.py).
    Returns (values, weights, area_codes) with any LA lacking a value for
    that year excluded from all three consistently.
    """
    official_code_by_key = dim.set_index("LA_Key")["AreaCode"]
    year_scoped = fact[fact["Year"] == year].drop_duplicates("LA_Key").copy()
    year_scoped["OfficialAreaCode"] = year_scoped["LA_Key"].map(official_code_by_key)
    values = year_scoped.set_index("OfficialAreaCode")["ONS_ratio_LQ"].reindex(area_codes)

    keep = ~values.isna()
    if (~keep).any():
        values = values[keep]
        weights = weights[np.ix_(keep.to_numpy(), keep.to_numpy())]
        area_codes = list(values.index)
    return values, weights, area_codes


# --- 4. Panel-year versions: Kruskal-Wallis and Moran's I for every year ---

def kruskal_wallis_all_years(fact: pd.DataFrame, start_year: int = 2005, end_year: int = 2024) -> pd.DataFrame:
    """
    Runs kruskal_wallis_by_region for every year in [start_year, end_year],
    returning one row per year. This is what makes the Kruskal-Wallis result
    filterable by the Year slicer in Power BI, rather than a single fixed
    2024 snapshot.
    """
    rows = []
    for year in range(start_year, end_year + 1):
        if year not in fact["Year"].values:
            continue
        result = kruskal_wallis_by_region(fact, year)
        rows.append({
            "Year": year,
            "H_statistic": result["H_statistic"],
            "p_value": result["p_value"],
            "significant_at_0.05": result["significant_at_0.05"],
            "n_observations": result["n_observations"],
            "n_regions": result["n_regions"],
        })
    return pd.DataFrame(rows)


def morans_i_all_years(fact: pd.DataFrame, dim: pd.DataFrame,
                         real_weights_path: Path | None = None,
                         start_year: int = 2005, end_year: int = 2024) -> pd.DataFrame:
    """
    Runs global Moran's I for every year in [start_year, end_year], both at
    regional level (approximate contiguity, always available) and at LA
    level (real weights, only if `real_weights_path` exists). Returns one
    row per year with both results side by side, so Power BI can filter a
    single table by Year and see how spatial clustering has evolved over
    the study period -- addressing the pipeline's own documented
    "further work" item.
    """
    has_real_weights = real_weights_path is not None and real_weights_path.exists()
    if has_real_weights:
        w_full, area_codes_full = load_real_weights(real_weights_path)

    rows = []
    for year in range(start_year, end_year + 1):
        if year not in fact["Year"].values:
            continue
        scoped = fact[fact["Year"] == year]
        regional_means = scoped.groupby("RegionName")["ONS_ratio_LQ"].mean()
        mi_regional = morans_i(regional_means, list(regional_means.index))

        row = {
            "Year": year,
            "morans_I_regional": mi_regional["morans_I"],
            "morans_I_regional_pvalue": mi_regional["p_value"],
            "morans_I_regional_significant": mi_regional["significant_at_0.05"],
        }

        if has_real_weights:
            values, w_year, codes_year = _la_values_for_year(fact, dim, year, area_codes_full, w_full)
            mi_la = morans_i(values, codes_year, weights=w_year)
            row.update({
                "morans_I_LA": mi_la["morans_I"],
                "morans_I_LA_pvalue": mi_la["p_value"],
                "morans_I_LA_significant": mi_la["significant_at_0.05"],
                "morans_I_LA_n_units": mi_la["n_units"],
            })
        rows.append(row)

    return pd.DataFrame(rows)


if __name__ == "__main__":
    fact = load_fact_table()
    dim = pd.read_csv(Path(__file__).parent / "data" / "dim_local_authority.csv")
    national = build_national_summary(fact)

    print("=== Mann-Kendall trend test: national median ratio, 2005-2024 ===")
    mk = mann_kendall(national.set_index("Year")["median_affordability_ratio"])
    for k, v in mk.items():
        print(f"  {k}: {v}")

    print("\n=== Kruskal-Wallis test: LA-level ratios across regions, 2024 ===")
    kw = kruskal_wallis_by_region(fact, 2024)
    print(f"  H = {kw['H_statistic']:.3f}, p = {kw['p_value']:.6f}, "
          f"significant = {kw['significant_at_0.05']} (n={kw['n_observations']} LAs, {kw['n_regions']} regions)")

    print("\n=== Moran's I: regional mean ratios, 2024 (approximate contiguity weights) ===")
    scoped = fact[fact["Year"] == 2024]
    regional_means = scoped.groupby("RegionName")["ONS_ratio_LQ"].mean()
    mi = morans_i(regional_means, list(regional_means.index))
    for k, v in mi.items():
        print(f"  {k}: {v}")

    real_weights_path = Path(__file__).parent / "data" / "la_spatial_weights.csv"
    if real_weights_path.exists():
        print(f"\n=== Real LA-level weights found ({real_weights_path.name}) -- "
              f"running authoritative LA-level Moran's I + LISA ===")
        w_full, area_codes_full = load_real_weights(real_weights_path)
        la_values, w, area_codes = _la_values_for_year(fact, dim, 2024, area_codes_full, w_full)

        mi_la = morans_i(la_values, area_codes, weights=w)
        for k, v in mi_la.items():
            print(f"  {k}: {v}")
        lisa = local_morans_i(la_values, area_codes, w)
        print(f"\n  Top 10 significant LISA clusters:")
        print(lisa[lisa["significant_at_0.05"]].head(10).to_string(index=False))
    else:
        print(f"\n(No real LA-level weights found at {real_weights_path}. "
              f"Run build_spatial_weights.py locally to generate one -- see README.)")
        real_weights_path = None

    print("\n=== Panel-year extension: Kruskal-Wallis for every year, 2005-2024 ===")
    kw_panel = kruskal_wallis_all_years(fact)
    print(kw_panel.to_string(index=False))

    print("\n=== Panel-year extension: Moran's I for every year, 2005-2024 ===")
    mi_panel = morans_i_all_years(fact, dim, real_weights_path)
    print(mi_panel.to_string(index=False))
