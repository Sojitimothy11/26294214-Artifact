#!/usr/bin/env python3
"""
run_pipeline.py
----------------
Single entry point that runs the full analytical pipeline end-to-end and
writes every output CSV/JSON to ./output/.

Usage:
    python run_pipeline.py

Pipeline stages (see individual modules for detail):
    1. ingest.py       - load harmonised LA-year panel + region lookup
    2. validate.py     - data-quality checks and anomaly detection
    3. aggregate.py    - national / regional / inequality (Gini) summaries
    4. divergence.py   - Price/Earnings Growth Index + Divergence Index
    5. inferential.py  - Mann-Kendall, Kruskal-Wallis, Moran's I, LISA
       (single-year snapshot AND full-panel year-by-year versions)

This is the Python analytical layer referenced in Dissertation Chapter 3.
Power BI consumes the CSVs written here as its data source; it performs
no independent statistical computation -- DAX measures in the dashboard
are aggregation/presentation only (e.g. SELECTEDVALUE-based interactivity,
simple MAX/MIN over already-clean data), never the source of a headline
statistic (Gini, growth indices, significance tests).
"""
import json
from pathlib import Path

import pandas as pd

import raw_ingest
from validate import run_validation
from aggregate import build_national_summary, build_regional_summary, build_inequality_summary
from divergence import build_divergence_index
from inferential import (
    mann_kendall, kruskal_wallis_by_region, morans_i, local_morans_i,
    load_real_weights, kruskal_wallis_all_years, morans_i_all_years,
    _la_values_for_year,
)

OUTPUT_DIR = Path(__file__).parent / "output"
REAL_WEIGHTS_PATH = Path(__file__).parent / "data" / "la_spatial_weights.csv"


def main():
    OUTPUT_DIR.mkdir(exist_ok=True)

    print("[1/6] Raw ingestion: joining ONS/Land Registry panel with official region lookup...")
    fact, dim = raw_ingest.run()
    fact.to_csv(OUTPUT_DIR / "fact_affordability_la_year.csv", index=False)
    dim.to_csv(OUTPUT_DIR / "dim_local_authority.csv", index=False)

    print("[2/6] Running validation checks...")
    val_summary, val_anomalies = run_validation(fact, dim)
    val_summary.to_csv(OUTPUT_DIR / "validation_summary.csv", index=False)
    val_anomalies.to_csv(OUTPUT_DIR / "validation_anomalies.csv", index=False)

    print("[3/6] Building national / regional / inequality summaries...")
    national = build_national_summary(fact)
    regional = build_regional_summary(fact)
    inequality = build_inequality_summary(fact)
    national.to_csv(OUTPUT_DIR / "summary_national_year.csv", index=False)
    regional.to_csv(OUTPUT_DIR / "summary_region_year.csv", index=False)
    inequality.to_csv(OUTPUT_DIR / "summary_inequality_year.csv", index=False)

    print("[4/6] Computing Divergence Index...")
    divergence = build_divergence_index(national)
    # Merge into the national summary so Power BI can consume one table
    national_extended = national.merge(divergence, on="Year", how="left")
    national_extended.to_csv(OUTPUT_DIR / "summary_national_year.csv", index=False)

    print("[5/6] Running inferential statistics (2024 snapshot + full panel)...")
    has_real_weights = REAL_WEIGHTS_PATH.exists()

    mk = mann_kendall(national.set_index("Year")["median_affordability_ratio"])
    kw_2024 = kruskal_wallis_by_region(fact, 2024)
    scoped_2024 = fact[fact["Year"] == 2024]
    regional_means_2024 = scoped_2024.groupby("RegionName")["ONS_ratio_LQ"].mean()
    mi_2024 = morans_i(regional_means_2024, list(regional_means_2024.index))

    inferential_results = {
        "mann_kendall_national_median_trend_2005_2024": mk,
        "kruskal_wallis_regional_ratios_2024": {
            k: v for k, v in kw_2024.items() if k != "region_medians"
        },
        "kruskal_wallis_regional_medians_2024": kw_2024["region_medians"],
        "morans_I_regional_means_2024": mi_2024,
    }

    if has_real_weights:
        w_full, area_codes_full = load_real_weights(REAL_WEIGHTS_PATH)
        la_values, w, area_codes = _la_values_for_year(fact, dim, 2024, area_codes_full, w_full)
        mi_la_2024 = morans_i(la_values, area_codes, weights=w)
        mi_la_2024["excluded_area_codes"] = [c for c in area_codes_full if c not in area_codes]
        inferential_results["morans_I_LA_level_2024"] = mi_la_2024

        lisa = local_morans_i(la_values, area_codes, w)
        lisa.to_csv(OUTPUT_DIR / "lisa_local_morans_i_la_2024.csv", index=False)
    else:
        print("  (No real LA-level weights found -- skipping LISA export and LA-level "
              "Moran's I. Run build_spatial_weights.py to enable these.)")

    with open(OUTPUT_DIR / "inferential_statistics.json", "w") as f:
        json.dump(inferential_results, f, indent=2, default=str)

    print("[6/6] Computing panel-year inferential statistics (2005-2024, every year)...")
    kw_panel = kruskal_wallis_all_years(fact)
    kw_panel.to_csv(OUTPUT_DIR / "kruskal_wallis_by_year.csv", index=False)

    mi_panel = morans_i_all_years(
        fact, dim, REAL_WEIGHTS_PATH if has_real_weights else None
    )
    mi_panel.to_csv(OUTPUT_DIR / "morans_i_by_year.csv", index=False)

    print(f"\nDone. All outputs written to {OUTPUT_DIR}/")
    for p in sorted(OUTPUT_DIR.glob("*")):
        print(f"  - {p.name}")


if __name__ == "__main__":
    main()
