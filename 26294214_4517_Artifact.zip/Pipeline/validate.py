"""
validate.py
-----------
Stage 2: data-quality validation checks on the harmonised panel.

Produces:
  - validation_summary.csv   : one row per check, with a single numeric result
  - validation_anomalies.csv : row-level detail for every anomaly flagged

These are the checks referenced in Dissertation Section 3.4 and cited
directly in the Discussion/Limitations chapters. Keeping them in code
(rather than only as static CSV output) makes them re-runnable against
any future refresh of the source data.
"""
import pandas as pd

ANALYSIS_START_YEAR = 2005
ANALYSIS_END_YEAR = 2024
RATIO_UPPER_FLAG = 20.0
RATIO_LOWER_FLAG = 1.0


def run_validation(fact: pd.DataFrame, dim: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    checks = {}

    # 1. Completeness: null values across all fact columns
    checks["fact_null_values_total"] = int(fact.isna().sum().sum())

    # 2. Analysis-window coverage: rows outside the 2005-2024 study period
    outside_range = fact[(fact["Year"] < ANALYSIS_START_YEAR) | (fact["Year"] > ANALYSIS_END_YEAR)]
    checks["rows_outside_analysis_range_2005_2024"] = int(len(outside_range))

    # 3. Referential integrity: fact rows whose region did not resolve after merge.
    # Joined on LA_Key (the uppercased-name key), matching the join actually used
    # by the production relationship in the Power BI model.
    merged = fact.merge(dim[["LA_Key", "RegionName"]], on="LA_Key", how="left",
                         suffixes=("", "_dim"))
    checks["rows_missing_region_after_merge"] = int(merged["RegionName_dim"].isna().sum())

    # 3b. Diagnostic: fact/dim AreaCode consistency for LAs that DO match on LA_Key.
    # This catches silent mismatches that a LA_Key-only join wouldn't surface --
    # e.g. an LA present in both tables under the same key but with a different
    # AreaCode, which would break any downstream join keyed on AreaCode instead.
    code_check = fact[["LA_Key", "AreaCode", "LA_Name"]].drop_duplicates().merge(
        dim[["LA_Key", "AreaCode"]], on="LA_Key", how="inner", suffixes=("_fact", "_dim")
    )
    area_code_mismatches = code_check[code_check["AreaCode_fact"] != code_check["AreaCode_dim"]]
    checks["distinct_LAs_with_AreaCode_mismatch_fact_vs_dim"] = int(len(area_code_mismatches))
    checks["fact_rows_affected_by_AreaCode_mismatch"] = int(
        fact[fact["LA_Key"].isin(area_code_mismatches["LA_Key"])].shape[0]
    )

    # 4. Dimension-table key uniqueness
    checks["duplicate_LA_Key_in_dimension"] = int(dim["LA_Key"].duplicated().sum())
    checks["duplicate_AreaCode_in_dimension"] = int(dim["AreaCode"].duplicated().sum())

    # 5. Plausibility flags: extreme ratio values worth a manual look
    above = fact[fact["ONS_ratio_LQ"] > RATIO_UPPER_FLAG].copy()
    above["issue"] = "ratio_above_20"
    below = fact[fact["ONS_ratio_LQ"] < RATIO_LOWER_FLAG].copy()
    below["issue"] = "ratio_below_1"
    checks["rows_with_ratio_above_20"] = int(len(above))
    checks["rows_with_ratio_below_1"] = int(len(below))

    code_mismatch_rows = fact[fact["LA_Key"].isin(area_code_mismatches["LA_Key"])].copy()
    code_mismatch_rows["issue"] = "area_code_mismatch_fact_vs_dim"

    anomalies = pd.concat([above, below, code_mismatch_rows], ignore_index=True)
    summary = pd.DataFrame({"check": list(checks.keys()), "value": list(checks.values())})
    return summary, anomalies


if __name__ == "__main__":
    from ingest import load_fact_table, load_dim_table
    fact = load_fact_table()
    dim = load_dim_table()
    summary, anomalies = run_validation(fact, dim)
    print(summary.to_string(index=False))
    print(f"\n{len(anomalies)} anomaly rows flagged (informational, not excluded from analysis)")
