"""
aggregate.py
------------
Stage 3: national and regional aggregation, and the Gini-coefficient
spatial-inequality series. This is the computational core referenced in
Dissertation Section 3.8 -- it is implemented here in Python, not in DAX,
which is the architectural correction this pipeline exists to make
explicit and reproducible.

Produces:
  - summary_national_year.csv
  - summary_region_year.csv
  - summary_inequality_year.csv (includes the Gini series)
"""
import numpy as np
import pandas as pd
from ingest import load_fact_table

ANALYSIS_START_YEAR = 2005
ANALYSIS_END_YEAR = 2024


def gini_coefficient(values: np.ndarray) -> float:
    """
    Gini coefficient of an array of non-negative values, using the standard
    mean absolute difference formulation:

        G = sum_i sum_j |x_i - x_j| / (2 * n^2 * mean(x))

    Matches the definition given in Dissertation Section 3.8.
    """
    x = np.sort(np.asarray(values, dtype=float))
    n = len(x)
    if n == 0 or x.mean() == 0:
        return np.nan
    # Efficient O(n log n) form of the mean-absolute-difference formula,
    # equivalent to the O(n^2) double sum but avoids materialising an
    # n x n pairwise-difference matrix.
    index = np.arange(1, n + 1)
    return float((2 * np.sum(index * x) - (n + 1) * np.sum(x)) / (n * np.sum(x)))


def _add_yoy_pct(df: pd.DataFrame, cols: list[str], group_cols: list[str] | None = None) -> pd.DataFrame:
    df = df.copy()
    grouped = df.groupby(group_cols) if group_cols else [(None, df)]
    for col in cols:
        yoy_col = f"{col}_yoy_pct"
        if group_cols:
            df[yoy_col] = df.groupby(group_cols)[col].pct_change() * 100
        else:
            df = df.sort_values("Year")
            df[yoy_col] = df[col].pct_change() * 100
    return df


def build_national_summary(fact: pd.DataFrame) -> pd.DataFrame:
    scoped = fact[(fact["Year"] >= ANALYSIS_START_YEAR)
                  & (fact["Year"] <= ANALYSIS_END_YEAR)]
    g = scoped.groupby("Year")["ONS_ratio_LQ"]
    out = pd.DataFrame({
        "Year": g.median().index,
        "median_affordability_ratio": g.median().values,
        "mean_affordability_ratio": g.mean().values,
        "avg_house_price": scoped.groupby("Year")["AveragePrice_annual"].mean().values,
        "avg_implied_lq_earnings": scoped.groupby("Year")["Implied_LQ_earnings"].mean().values,
        "authority_count": g.count().values,
        "max_affordability_ratio": g.max().values,
        "min_affordability_ratio": g.min().values,
    })
    out["inequality_range"] = out["max_affordability_ratio"] - \
        out["min_affordability_ratio"]
    out = _add_yoy_pct(out, [
        "median_affordability_ratio", "mean_affordability_ratio",
        "avg_house_price", "avg_implied_lq_earnings",
    ])
    return out.sort_values("Year").reset_index(drop=True)


def build_regional_summary(fact: pd.DataFrame) -> pd.DataFrame:
    scoped = fact[(fact["Year"] >= ANALYSIS_START_YEAR)
                  & (fact["Year"] <= ANALYSIS_END_YEAR)]
    g = scoped.groupby(["RegionName", "Year"])
    out = g.agg(
        mean_affordability_ratio=("ONS_ratio_LQ", "mean"),
        median_affordability_ratio=("ONS_ratio_LQ", "median"),
        avg_house_price=("AveragePrice_annual", "mean"),
        avg_implied_lq_earnings=("Implied_LQ_earnings", "mean"),
        authority_count=("ONS_ratio_LQ", "count"),
        max_affordability_ratio=("ONS_ratio_LQ", "max"),
        min_affordability_ratio=("ONS_ratio_LQ", "min"),
    ).reset_index()
    out["inequality_range"] = out["max_affordability_ratio"] - \
        out["min_affordability_ratio"]
    out = out.sort_values(["RegionName", "Year"])
    out = _add_yoy_pct(out, [
        "mean_affordability_ratio", "median_affordability_ratio",
        "avg_house_price", "avg_implied_lq_earnings",
    ], group_cols=["RegionName"])
    return out.reset_index(drop=True)


def build_inequality_summary(fact: pd.DataFrame) -> pd.DataFrame:
    scoped = fact[(fact["Year"] >= ANALYSIS_START_YEAR)
                  & (fact["Year"] <= ANALYSIS_END_YEAR)]
    rows = []
    for year, grp in scoped.groupby("Year"):
        ratios = grp["ONS_ratio_LQ"].values
        rows.append({
            "Year": year,
            "max_affordability_ratio": ratios.max(),
            "min_affordability_ratio": ratios.min(),
            "median_affordability_ratio": np.median(ratios),
            "mean_affordability_ratio": ratios.mean(),
            "authority_count": len(ratios),
            "inequality_range": ratios.max() - ratios.min(),
            "gini_affordability_ratio": gini_coefficient(ratios),
            "std_dev_affordability_ratio": ratios.std(ddof=1),
        })
    out = pd.DataFrame(rows).sort_values("Year").reset_index(drop=True)
    out = _add_yoy_pct(out, ["gini_affordability_ratio",
                       "inequality_range", "std_dev_affordability_ratio"])
    return out


if __name__ == "__main__":
    fact = load_fact_table()
    national = build_national_summary(fact)
    regional = build_regional_summary(fact)
    inequality = build_inequality_summary(fact)
    print("National summary (head):")
    print(national.head(3).to_string(index=False))
    print("\nInequality summary (head):")
    print(inequality.head(3).to_string(index=False))
