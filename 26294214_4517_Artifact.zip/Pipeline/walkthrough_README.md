# Housing Affordability Analytical Pipeline

Reproducible Python pipeline that computes every statistic quoted in the
dissertation from the harmonised LA-year panel. Power BI is a downstream
consumer of these outputs only — it performs no independent statistical
computation.

## Architecture

```
data/                                                            raw inputs
  england_LA_affordability_2002_2025.csv                         ONS LQ PTE ratio + HM Land Registry
                                                                  price panel, pre-region-join (RegionName
                                                                  column here is a placeholder -- see
                                                                  raw_ingest.py docstring)
  Local_Authority_District_to_Region__December_2024__Lookup_in_EN.csv
                                                                  official ONS LAD-to-region lookup

raw_ingest.py       Stage 0: join the raw panel with the official region lookup;
                     produces fact_affordability_la_year.csv + dim_local_authority.csv
ingest.py            (used only by individual modules' standalone test runs;
                     run_pipeline.py calls raw_ingest.run() directly)
validate.py         Stage 1: data-quality checks, anomaly detection
aggregate.py         Stage 2: national / regional summaries, Gini coefficient series
divergence.py         Stage 3: Price/Earnings Growth Index, Divergence Index
inferential.py         Stage 4: Mann-Kendall trend test, Kruskal-Wallis, Moran's I

run_pipeline.py    Orchestrator -- runs all stages, writes output/
```

## Running it

```bash
pip install -r requirements.txt
python run_pipeline.py
```

Outputs land in `output/`:

| File | Contents |
|---|---|
| `fact_affordability_la_year.csv` | Rebuilt LA-year panel, region-joined from raw sources |
| `dim_local_authority.csv` | LA-to-region lookup, from the official ONS boundary file |
| `validation_summary.csv` | One row per data-quality check |
| `validation_anomalies.csv` | Row-level detail for every flagged anomaly |
| `summary_national_year.csv` | National medians/means, growth indices, Divergence Index, YoY% |
| `summary_region_year.csv` | Same, by region and year |
| `summary_inequality_year.csv` | Gini coefficient series and inequality range, by year |
| `inferential_statistics.json` | Mann-Kendall, Kruskal-Wallis, Moran's I results |

These are the exact files loaded into the Power BI data model (Get Data →
Text/CSV, or folder query pointed at `output/`).

## What changed vs. the original ad-hoc pipeline

1. **True raw ingestion, not just re-aggregation.** `raw_ingest.py` now builds
   `fact_affordability_la_year.csv` and `dim_local_authority.csv` directly from
   `england_LA_affordability_2002_2025.csv` (the merged ONS+Land Registry panel)
   and the official ONS LAD-to-region lookup, rather than assuming those two
   tables as a given starting point. Both rebuilt tables were diffed
   cell-by-cell against the previously-used versions: **zero mismatches**
   across all 7,041 fact rows and all 296 dimension rows. This closes what
   was previously the least reproducible part of the pipeline -- the region
   join described in Dissertation Section 3.4.
2. **Reproducibility.** Every summary number in the dissertation can now be
   regenerated from the two closest-to-source files available, by re-running
   one script, rather than existing only as static, undocumented CSVs.
3. **A genuine bug was found and fixed in validation -- and traced to its
   origin.** The `rows_missing_region_after_merge` check originally reported
   0 without testing AreaCode referential integrity. Re-deriving it surfaced
   a real mismatch: Barnsley and Sheffield carry different `AreaCode` values
   in the raw ONS/Land Registry panel (`E08000038`/`E08000039`) than in the
   official region lookup (`E08000016`/`E08000019`, the correct current ONS
   codes) -- 48 rows affected. This was confirmed to originate in the raw
   source file itself, not introduced by any downstream processing. The
   Power BI model is unaffected because its active relationship joins on
   `LA_Key` (uppercased name), not `AreaCode`, but this is now an explicit,
   re-runnable check (`distinct_LAs_with_AreaCode_mismatch_fact_vs_dim`)
   rather than a silent gap.
4. **Divergence Index added.** Closes the gap between Dissertation Table 7
   (which claims this measure exists) and the actual model (which didn't
   have it). Computed in Python as `price_growth_index - earnings_growth_index`.
5. **Inferential statistics added**, addressing the dissertation's own
   stated limitation (Section 3.10) that the dashboard offers no
   hypothesis testing:
   - **Mann-Kendall trend test** on the national median ratio — tests
     whether the 2005–2024 trend is statistically significant, not just
     visually apparent.
   - **Kruskal-Wallis H test** on LA-level ratios across regions — a
     non-parametric ANOVA analogue, appropriate given the right-skewed
     ratio distribution (a small number of very high-ratio London
     boroughs).
   - **Moran's I** on regional mean ratios — tests for significant
     positive spatial autocorrelation (do neighbouring regions have more
     similar affordability than chance predicts?). This is the one
     addition most worth foregrounding in the dissertation: it directly
     operationalises the Anselin (1988) spatial econometrics citation in
     the literature review with an actual spatial statistic, which
     Chapter 4 currently lacks (the choropleth map is a visualisation,
     not a statistical test).

## Moran's I spatial weights: real LA-level analysis available, run locally

**Update:** this is now a two-tier system rather than a single fixed limitation.

`inferential.py` automatically checks for `data/la_spatial_weights.csv`. If
present, it runs the **authoritative LA-level (n=294) Moran's I and Local
Moran's I (LISA)** using real spatial weights. If absent, it falls back to
the documented approximate 9-region contiguity matrix. Every result now
carries an explicit `weights_source` field (`"real (LA-level, supplied)"`
or `"approximate (9-region contiguity)"`) so it's never ambiguous which
mode produced a given number.

**Why the real weights aren't generated automatically here:** this
pipeline-execution environment has no network access to download the ONS
boundary files, and when fetched through an available web tool the files
come back as large binaries behind expiring signed URLs that can't be
saved to disk in this environment. This was tested directly, not assumed.

**To generate the real weights matrix, run `build_spatial_weights.py` on
your own machine** (which has both internet access and can install a
geospatial stack):

```bash
pip install geopandas libpysal
python build_spatial_weights.py
```

This downloads the official ONS Local Authority Districts (December 2024)
boundary file, builds a real queen-contiguity weights matrix restricted to
the 294 LAs in the study panel, and writes `data/la_spatial_weights.csv`.
It joins against `dim_local_authority.csv`'s **official** AreaCodes (not
the fact table's raw AreaCode column), which matters specifically because
of the Barnsley/Sheffield AreaCode inconsistency described above --
`inferential.py`'s LA-level lookup joins back via `LA_Key` for the same
reason, so those two LAs aren't silently dropped from the analysis.

Once `data/la_spatial_weights.csv` exists, just re-run `run_pipeline.py`
or `inferential.py` -- no other code changes needed. This also unlocks
**Local Moran's I (LISA)**, which identifies *specific* hot-spot/cold-spot
LA clusters (not just a single global statistic) -- a natural, citable
extension of the existing spatial hotspot page (Page 5) rather than a
departure from it, and the strongest remaining upgrade to the spatial
inequality analysis before submission.

## Verification

Every summary CSV in this pipeline was checked cell-by-cell against the
previously existing `summary_national_year.csv`, `summary_region_year.csv`,
and `summary_inequality_year.csv` — **zero numeric discrepancies** — before
any new computation (Divergence Index, inferential stats) was added. The
new checks in `validate.py` were similarly checked against the original
`validation_summary.csv` after aligning the join key to match the one
actually used by the production Power BI relationship (`LA_Key`).
