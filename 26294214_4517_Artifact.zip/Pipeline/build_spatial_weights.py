#!/usr/bin/env python3
"""
build_spatial_weights.py
--------------------------
RUN THIS ON YOUR OWN MACHINE, NOT IN THE SANDBOXED PIPELINE ENVIRONMENT.

Why this is a separate script: the environment that ran the rest of this
pipeline has no network access, and the ONS boundary files are served as
large binaries behind expiring signed URLs that couldn't be retrieved or
processed there. This script does the one step that genuinely requires
your own machine's internet access and a geospatial stack.

What it does:
  1. Downloads the official ONS Local Authority Districts (December 2024)
     boundary file (BUC -- ultra generalised, 500m -- resolution is
     plenty for contiguity/adjacency purposes; no need for full-resolution
     coastline detail).
  2. Builds a real queen-contiguity spatial weights matrix at LA level
     (n=294, not the n=9 regional approximation used as a fallback in
     inferential.py).
  3. Patches any queen-contiguity islands (LAs with no shared-border
     neighbours, e.g. Isle of Wight, Isles of Scilly) with a single
     nearest-centroid neighbour via KNN(k=1), so every LA has at least
     one neighbour and none are silently dropped from Local Moran's I.
  4. Row-standardises it and writes it to data/la_spatial_weights.csv.

Once that file exists, run_pipeline.py / inferential.py will automatically
detect and use it instead of the approximate regional matrix -- no other
code changes needed.

Setup (on your machine):
    pip install geopandas libpysal

Usage:
    python build_spatial_weights.py
"""
from pathlib import Path

import geopandas as gpd
import pandas as pd
from libpysal.weights import Queen, KNN, W

# ONS Open Geography Portal: Local Authority Districts (December 2024)
# Boundaries UK BGC (20m generalised, clipped to coastline). This resolution
# is more than sufficient for contiguity/adjacency purposes -- there's no
# need for full coastline detail just to determine which LAs border which.
# Verified working as of July 2026. If it 404s by the time you run this
# (ONS occasionally reorganises the portal), search "Local Authority
# Districts December 2024 Boundaries UK BUC" or "...BGC" on data.gov.uk,
# open the GeoJSON resource page, and copy the "Go to resource" link --
# it will look like https://open-geography-portalx-ons.hub.arcgis.com/api/download/v1/items/<ITEM_ID>/geojson?layers=0
BOUNDARY_URL = (
    "https://open-geography-portalx-ons.hub.arcgis.com/api/download/v1/items/"
    "6a05f93297cf4a438d08e972099f54b9/geojson?layers=0"
)

DATA_DIR = Path(__file__).parent / "data"
OUTPUT_DIR = Path(__file__).parent / "output"
DIM_PATH = OUTPUT_DIR / "dim_local_authority.csv"
OUTPUT_PATH = DATA_DIR / "la_spatial_weights.csv"


def main():
    print(f"Downloading LA boundaries from {BOUNDARY_URL} ...")
    gdf = gpd.read_file(BOUNDARY_URL)

    # Restrict to England LAs actually present in the study panel, so the
    # weights matrix aligns exactly with fact_affordability_la_year.csv.
    # Uses dim_local_authority.csv (official ONS AreaCodes), NOT the fact
    # table's AreaCode column directly -- the fact table carries the known
    # raw-source AreaCode inconsistency for Barnsley/Sheffield (see
    # raw_ingest.py docstring), and joining against official codes here
    # avoids re-introducing that same mismatch into the spatial weights.
    dim = pd.read_csv(DIM_PATH)
    study_area_codes = dim["AreaCode"].unique().tolist()

    code_col = "LAD24CD" if "LAD24CD" in gdf.columns else "LAD23CD"
    gdf = gdf[gdf[code_col].isin(study_area_codes)].sort_values(code_col).reset_index(drop=True)

    missing = set(study_area_codes) - set(gdf[code_col])
    if missing:
        print(f"WARNING: {len(missing)} AreaCodes in the study panel were not found in the "
              f"boundary file (e.g. due to the known raw-data AreaCode inconsistency for "
              f"Barnsley/Sheffield -- see raw_ingest.py docstring). These will be excluded "
              f"from the spatial weights matrix: {sorted(missing)}")

    print(f"Building queen-contiguity weights for {len(gdf)} local authorities...")
    w = Queen.from_dataframe(gdf, use_index=False)

    if w.islands:
        island_names = [gdf.loc[i, "LAD24NM" if "LAD24NM" in gdf.columns else code_col] for i in w.islands]
        print(f"Found {len(w.islands)} queen-contiguity island(s) with no shared-border "
              f"neighbours ({island_names}) -- patching each with its single nearest "
              f"neighbour by centroid distance (KNN, k=1) so none are dropped from LISA.")
        knn1 = KNN.from_dataframe(gdf, k=1)
        neighbors = {k: list(v) for k, v in w.neighbors.items()}
        weights = {k: list(v) for k, v in w.weights.items()}
        for island in w.islands:
            nearest = int(knn1.neighbors[island][0])
            neighbors[island] = [nearest]
            weights[island] = [1.0]
            if island not in neighbors[nearest]:
                neighbors[nearest].append(island)
                weights[nearest].append(1.0)
        w = W(neighbors, weights, silence_warnings=True)

    w.transform = "r"  # row-standardise

    weights_df = pd.DataFrame(
        w.full()[0],
        index=gdf[code_col],
        columns=gdf[code_col],
    )

    DATA_DIR.mkdir(exist_ok=True)
    weights_df.to_csv(OUTPUT_PATH)
    print(f"Wrote real LA-level spatial weights matrix to {OUTPUT_PATH} "
          f"({weights_df.shape[0]} x {weights_df.shape[1]}, no islands)")
    print("\nRe-run run_pipeline.py (or inferential.py) -- it will now use this "
          "automatically instead of the approximate regional matrix.")


if __name__ == "__main__":
    main()
