"""
ingest.py
---------
Loader for the already-generated output CSVs, used only by each pipeline
module's standalone `python <module>.py` test run (requires run_pipeline.py
to have been run at least once already). The full pipeline (run_pipeline.py)
builds fact/dim in memory directly via raw_ingest.run() and never imports
this module.
"""
from pathlib import Path
import pandas as pd

OUTPUT_DIR = Path(__file__).parent / "output"


def load_fact_table() -> pd.DataFrame:
    return pd.read_csv(OUTPUT_DIR / "fact_affordability_la_year.csv")


def load_dim_table() -> pd.DataFrame:
    return pd.read_csv(OUTPUT_DIR / "dim_local_authority.csv")
